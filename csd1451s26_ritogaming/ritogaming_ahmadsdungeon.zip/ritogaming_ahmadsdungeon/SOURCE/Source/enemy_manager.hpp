﻿/*!************************************************************************
\file:          enemy_manager.hpp
\author:        Claire
\par DP email:  c.cheong@digipen.edu

\brief:         EnemyManager implementation. All previously hardcoded
                magic numbers (filepaths, timings, sizes, particle params)
                are now read directly from the e_ globals defined in
                enemy.cpp and declared extern in enemy.hpp, populated
                once at startup by dave_Data().
**************************************************************************/

#pragma once

#include <vector>
#include <memory>
#include <string>
#include <algorithm>
#include "AEEngine.h"
#include "enemy.hpp"
#include "player.hpp"
#include "utils.hpp"

// ============================================================================
// LOGIC CONSTANTS
// ----------------------------------------------------------------------------
// Timing and gameplay constants for spawning, respawning, and food lifetime.
// ============================================================================
static constexpr f32 SPAWN_CHECK_INTERVAL = 3.f;   // Interval to check for respawns
static constexpr f32 RESPAWN_DELAY = 5.f;   // Time before a defeated enemy can respawn
static constexpr f32 FOOD_LIFTIME = 9.f;   // Duration food remains active in the world

// ============================================================================
// GAME ZONES
// ----------------------------------------------------------------------------
// Used to identify the current gameplay area and control enemy behavior.
// ============================================================================
enum game_zone { tutorial_area, combat_area, boss_room };

// ============================================================================
// STRUCTS
// ----------------------------------------------------------------------------
// Represents a single food drop in the game world.
// ============================================================================
struct food_drop {
    f32 x, y;       // World position
    f32 size;       // Render size
    f32 lifetime;   // Remaining lifetime
    bool active;    // Is the food currently available?
    AEGfxTexture* texture; // Associated texture
};

// Represents an enemy slot for managing respawn logic.
struct enemy_slot {
    base_enemy* enemy;    // Pointer to the enemy occupying this slot
    f32 respawn_timer;    // Timer until the enemy respawns
};

// ============================================================================
// ENEMY MANAGER CLASS
// ----------------------------------------------------------------------------
// Handles enemy creation, updating, rendering, respawning, food drops, and
// VFX like respawn particles. Supports multiple enemy types and zones.
// ============================================================================
class EnemyManager {
private:
    // ---------------------------- Core Data -----------------------------
    std::vector<std::unique_ptr<base_enemy>> enemies;  // Active enemy instances
    std::vector<food_drop>                   food_drops;
    std::vector<Particle>                    respawn_particles;

    // ------------------------ Dynamic Arrays ---------------------------
    enemy_slot* ghost_slots;
    enemy_slot* bat_slots;
    AEVec2* ghost_spawn_positions;
    AEVec2* bat_spawn_positions;
    AEVec2* cross_positions;

    // ------------------------ Dynamic Counts ---------------------------
    int ghost_count;
    int bat_count;
    int cross_count;

    // ---------------------------- Textures -----------------------------
    AEGfxTexture* cross_tex{ nullptr };
    AEGfxTexture* ghost_marker_tex{ nullptr };
    AEGfxTexture* bat_marker_tex{ nullptr };
    AEGfxTexture* ghost_tex{ nullptr };
    AEGfxTexture* bat_tex{ nullptr };
    AEGfxTexture* dragon_tex{ nullptr };
    AEGfxTexture* ghost_food_tex{ nullptr };
    AEGfxTexture* bat_food_tex{ nullptr };
    AEGfxTexture* dragon_food_tex{ nullptr };

    // -------------------------- State Variables ------------------------
    bool      spawn_positions_loaded{ false };
    f32       spawn_check_timer{ 0.0f };
    game_zone current_zone{ tutorial_area };
    bool      boss_room_entered{ false };
    int       enemies_defeated{ 0 };

public:
    // ------------------------- Lifecycle --------------------------------
    EnemyManager();
    ~EnemyManager();

    void load_textures();                               // Load textures for enemies and markers
    void unload_textures();                             // Release all loaded textures
    void update(Player* player, Camera::camera* cam); // Update all enemies, food, and particles
    void render();                                      // Render enemies, food, and particles

    // -------------------------- Setup ----------------------------------
    void set_zone(game_zone zone) { current_zone = zone; }
    void initialize_tutorial_area();                    // Spawn enemies for tutorial
    void initialize_combat_area();                      // Spawn enemies for combat
    void load_spawn_positions(const char* filename);   // Load enemy spawn positions from file
    void clear_all();                                   // Clear all enemies, food, and particles

    // ------------------------ Spawning ---------------------------------
    void spawn_ghost_at_slot(s32 idx);
    void spawn_bat_at_slot(s32 idx);
    void spawn_dragon(f32 x, f32 y, f32 r_left, f32 r_right, f32 r_top, f32 r_bottom);
    void maintain_ghost_population();                  // Respawn ghosts as needed
    void maintain_bat_population();                    // Respawn bats as needed

    // -------------------- VFX & Feedback -------------------------------
    void spawn_respawn_particles(f32 x, f32 y);
    void spawn_food(f32 x, f32 y, AEGfxTexture* texture);

    // -------------------------- Combat ---------------------------------
    void check_player_attacks(Player* player, f32 range, f32 damage);
    bool check_projectile_hit(f32 px, f32 py, f32 radius, f32 damage);
    void cleanup_dead_enemies();

    // --------------------------- Getters --------------------------------
    size_t get_active_enemy_count() const;
    bool   save_spawn_positions_from_map(s32** map_data, const std::string& filename);
    int get_ghost_count_dynamic() const { return ghost_count; }
    int get_bat_count_dynamic() const { return bat_count; }
    std::vector<std::unique_ptr<base_enemy>> const& get_enemies() const { return enemies; }

private:
    void update_food(Player* player);          // Update food timers and collisions
    void render_food();                                // Draw active food drops
    void render_enemy(base_enemy* enemy);             // Draw individual enemy
    void render_spawn_markers();                       // Draw markers for spawn positions
    void update_respawn_particles();            // Update respawn particle positions
    void render_respawn_particles();                  // Draw respawn particles
};

// Global instance
extern EnemyManager enemy_manager_instance;

// Helper to update projectiles system
void entity_system_update(Player* player_ptr, EnemyManager* enem);